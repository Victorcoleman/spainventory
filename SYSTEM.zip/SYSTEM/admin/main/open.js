// Get modal element
var modal = document.getElementById('myModal');
    
// Get open modal button
var btn = document.getElementById('openModal');

// Get close button
var span = document.getElementsByClassName('close')[0];

// Listen for open click
btn.onclick = function() {
    modal.style.display = 'block';
}

// Listen for close click
span.onclick = function() {
    modal.style.display = 'none';
}

// Listen for outside click
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}