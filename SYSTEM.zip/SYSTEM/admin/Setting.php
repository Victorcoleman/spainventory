<?php
include '../db/connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Hash the password using MD5
    $hashed_password = md5($password);

    // Insert the new user into the database
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";

    if (mysqli_query($conn, $query)) {
        echo '<script>alert("New user added successfully!");</script>';
        header('Location: Setting.php');
        exit();
    } else {
        echo 'Error: ' . $query . '<br>' . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>

<body>
    <?php 
    include './component/sidebar.php'; 
    include './component/header.php'; 
    include '../db/connection.php'; 
    ?>

    <body>
        <div class="d-flex vh-100">
            <div class="container my-auto">
                <div class="text-center">
                    <!-- Button to Open the Modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adminModal">
                        Add Admin Data
                    </button>
                </div>

                <!-- Add Admin Modal -->
                <div class="modal fade" id="adminModal" tabindex="-1" aria-labelledby="adminModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h5 class="modal-title" id="adminModalLabel">Add Admin Data</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>

                            <!-- Modal Body -->
                            <div class="modal-body">
                                <form action="Setting.php" method="POST">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" name="password"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="role" class="form-label">Role</label>
                                        <select class="form-select" id="role" name="role" required>
                                            <option value="admin">Admin</option>
                                            <option value="user">User</option>
                                        </select>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- User List Table -->
                <div class="table-responsive mt-4">
                    <table class="table table-bordered table-striped text-center">
                        <thead class="table-dark">
                            <tr>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        $sql = 'SELECT * FROM users';
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . htmlspecialchars($row['username']) . '</td>';
                                echo '<td>' . htmlspecialchars($row['role']) . '</td>';
                                echo "<td>
                                    <button class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#updateRoleModal' 
                                            data-userid='" . $row['user_id'] . "' data-username='" . htmlspecialchars($row['username']) . "' 
                                            data-role='" . $row['role'] . "'>Update Role</button>
                                    <button class='btn btn-danger' onclick='confirmDelete(" . $row['user_id'] . ")'>Delete</button>
                                  </td>";
                                echo '</tr>';
                            }
                        } else {
                            echo "<tr><td colspan='3'>No users found</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
        // Populate Update Role Modal
        document.getElementById('updateRoleModal').addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget;
            var userId = button.getAttribute('data-userid');
            var username = button.getAttribute('data-username');
            var role = button.getAttribute('data-role');

            var modal = this;
            modal.querySelector('#userId').value = userId;
            modal.querySelector('#username').value = username;
            modal.querySelector('#role').value = role;
        });
        </script>
    </body>

</html>