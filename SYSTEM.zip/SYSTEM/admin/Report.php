<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>

<body>
    <?php include './component/sidebar.php'; ?>
    <?php include './component/header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Generate Reports</h1>
        <form method="GET" action="" class="my-4">
            <div class="row">
                <div class="col-md-4">
                    <label for="start-date" class="form-label">Start Date:</label>
                    <input type="date" id="start-date" name="start_date" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label for="end-date" class="form-label">End Date:</label>
                    <input type="date" id="end-date" name="end_date" class="form-control" required>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Generate Report</button>
                </div>
            </div>
        </form>

        <?php
        if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];

            // Database connection
            include '../db/connection.php';  // Ensure you have a proper database connection script

            // Fetch data
            $queries = [
                "appointments" => "SELECT * FROM appointments WHERE created_at BETWEEN '$start_date' AND '$end_date'",
                "orders" => "SELECT * FROM orders WHERE created_at BETWEEN '$start_date' AND '$end_date'",
                "inventory" => "SELECT * FROM inventory WHERE LastRestocked BETWEEN '$start_date' AND '$end_date'",
                "subscriptions" => "SELECT * FROM subscriptions WHERE subscribed_at BETWEEN '$start_date' AND '$end_date'",
            ];

            $data = [];
            foreach ($queries as $key => $query) {
                $result = $conn->query($query);
                if ($result) {
                    $data[$key] = $result->fetch_all(MYSQLI_ASSOC);
                } else {
                    $data[$key] = [];
                }
            }

            $conn->close();
        ?>

        <div class="mt-4">
            <h2>Report Results (From: <?php echo $start_date; ?> To: <?php echo $end_date; ?>)</h2>
            <hr>

            <h3>Appointments</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Type</th>
                        <th>Cost</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['appointments'] as $appointment) { ?>
                    <tr>
                        <td><?php echo $appointment['id']; ?></td>
                        <td><?php echo $appointment['first_name']; ?></td>
                        <td><?php echo $appointment['last_name']; ?></td>
                        <td><?php echo $appointment['email']; ?></td>
                        <td><?php echo $appointment['phone_number']; ?></td>
                        <td><?php echo $appointment['address']; ?></td>
                        <td><?php echo $appointment['appointment_type']; ?></td>
                        <td><?php echo $appointment['cost']; ?></td>
                        <td><?php echo $appointment['created_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>Orders</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Product</th>
                        <th>Cost</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['orders'] as $order) { ?>
                    <tr>
                        <td><?php echo $order['id']; ?></td>
                        <td><?php echo $order['first_name']; ?></td>
                        <td><?php echo $order['last_name']; ?></td>
                        <td><?php echo $order['email']; ?></td>
                        <td><?php echo $order['phone_number']; ?></td>
                        <td><?php echo $order['address']; ?></td>
                        <td><?php echo $order['product']; ?></td>
                        <td><?php echo $order['cost']; ?></td>
                        <td><?php echo $order['created_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>Inventory</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Inventory ID</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Price Per Unit</th>
                        <th>Product</th>
                        <th>Last Restocked</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['inventory'] as $item) { ?>
                    <tr>
                        <td><?php echo $item['InventoryID']; ?></td>
                        <td><?php echo $item['ItemName']; ?></td>
                        <td><?php echo $item['Quantity']; ?></td>
                        <td><?php echo $item['PricePerUnit']; ?></td>
                        <td><?php echo $item['Product']; ?></td>
                        <td><?php echo $item['LastRestocked']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>Subscriptions</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Subscribed At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['subscriptions'] as $subscription) { ?>
                    <tr>
                        <td><?php echo $subscription['id']; ?></td>
                        <td><?php echo $subscription['email']; ?></td>
                        <td><?php echo $subscription['subscribed_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <?php
        } // End of if condition
        ?>
    </div>

    <?php include './component/footer.php'; ?>

    <!-- Bootstrap and JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>