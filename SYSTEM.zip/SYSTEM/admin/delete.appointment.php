<?php include './component/header.php' ?>
<?php
// Include the database connection file
include '../db/connection.php';

// Check if the staff ID is provided via GET request
if ( isset( $_GET[ 'id' ] ) ) {
    // Get the staff ID from the URL parameter
    $id = $_GET[ 'id' ];

    // Prepare the SQL query to delete the staff from the database
    $sql = 'DELETE FROM Appointments WHERE  id = ?';
    $stmt = $conn->prepare( $sql );

    // Bind the staff ID parameter
    $stmt->bind_param( 'i', $id );

    // Execute the SQL query
    if ( $stmt->execute() ) {
        // Redirect to the staff listing page after successful deletion
        header( 'Location: Appointments.php' );
        exit;
    } else {
        // Display error message if deletion fails
        echo 'Failed to delete Appointments: ' . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<?php include './component/footer.php' ?>