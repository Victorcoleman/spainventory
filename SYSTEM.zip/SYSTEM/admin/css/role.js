// Pre-fill Update Role Modal with user data
document.getElementById('updateRoleModal').addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var userId = button.getAttribute('data-userid');
    var username = button.getAttribute('data-username');
    var role = button.getAttribute('data-role');

    var modal = this;
    modal.querySelector('#userId').value = userId;
    modal.querySelector('#username').value = username;
    modal.querySelector('#role').value = role;
});

// Delete confirmation
function confirmDelete(userId) {
    if (confirm("Are you sure you want to delete this user?")) {
        window.location.href = "delete_user.php?user_id=" + userId;
    }
}
