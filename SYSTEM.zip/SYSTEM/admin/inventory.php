<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>

<body>
    <?php 
    include './component/sidebar.php'; 
    include './component/header.php'; 
    include '../db/connection.php'; 

    // Initialize search query
    $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

    // Fetch data from inventory table with search functionality
    $sql = "SELECT * FROM inventory WHERE ItemName LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $searchQuery . "%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    // Handle form submissions for Add/Update inventory
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $itemName = $_POST['ItemName'];
        $quantity = $_POST['Quantity'];
        $pricePerUnit = $_POST['PricePerUnit'];
        $product = $_POST['Product'];
        $lastRestocked = $_POST['LastRestocked'];

        if (isset($_POST['InventoryID']) && $_POST['InventoryID']) {
            // Update inventory item
            $inventoryID = $_POST['InventoryID'];
            $updateSql = "UPDATE inventory SET ItemName = ?, Quantity = ?, PricePerUnit = ?, Product = ?, LastRestocked = ? WHERE InventoryID = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("siissi", $itemName, $quantity, $pricePerUnit, $product, $lastRestocked, $inventoryID);
            $updateStmt->execute();
        } else {
            // Add new inventory item
            $insertSql = "INSERT INTO inventory (ItemName, Quantity, PricePerUnit, Product, LastRestocked) VALUES (?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertSql);
            $insertStmt->bind_param("siiss", $itemName, $quantity, $pricePerUnit, $product, $lastRestocked);
            $insertStmt->execute();
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
    ?>

    <!-- Add/Update Form Section -->
    <div class="container mt-5">
        <h3 class="mb-3">Manage Inventory</h3>
        <div class="card mb-4">
            <div class="card-header bg-success text-white">Add / Update Inventory</div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <input type="hidden" name="InventoryID" id="InventoryID">
                            <label for="ItemName" class="form-label">Item Name</label>
                            <input type="text" class="form-control" id="ItemName" name="ItemName" required>
                        </div>
                        <div class="col-md-6">
                            <label for="Quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="Quantity" name="Quantity" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="PricePerUnit" class="form-label">Price Per Unit</label>
                            <input type="text" class="form-control" id="PricePerUnit" name="PricePerUnit" required>
                        </div>
                        <div class="col-md-6">
                            <label for="Product" class="form-label">Product</label>
                            <input type="text" class="form-control" id="Product" name="Product" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="LastRestocked" class="form-label">Last Restocked</label>
                        <input type="date" class="form-control" id="LastRestocked" name="LastRestocked" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Table Section -->
    <div class="container">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <span>Inventory List</span>
                    <form class="d-flex" method="GET" action="">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search ItemName..."
                            value="<?= htmlspecialchars($searchQuery) ?>" aria-label="Search">
                        <button class="btn btn-light" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price Per Unit</th>
                            <th>Product</th>
                            <th>Last Restocked</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $serialNumber = 1;
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $serialNumber++ . "</td>";
                                echo "<td>" . htmlspecialchars($row['ItemName']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['Quantity']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['PricePerUnit']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['Product']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['LastRestocked']) . "</td>";
                                echo "<td><button class='btn btn-warning btn-sm' onclick='editItem(" . json_encode($row) . ")'>Edit</button> ";
                                echo "<a class='btn btn-danger btn-sm' href='delete.inventory.php?id=" . htmlspecialchars($row['InventoryID']) . "' onclick='return confirm(\"Are you sure you want to delete this item?\")'>Delete</a></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>No data available</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
    $stmt->close();
    $conn->close();
    include './component/footer.php'; 
    ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function editItem(item) {
        document.getElementById('InventoryID').value = item.InventoryID;
        document.getElementById('ItemName').value = item.ItemName;
        document.getElementById('Quantity').value = item.Quantity;
        document.getElementById('PricePerUnit').value = item.PricePerUnit;
        document.getElementById('Product').value = item.Product;
        document.getElementById('LastRestocked').value = item.LastRestocked;
    }
    </script>
</body>

</html>