<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>
<?php include './component/sidebar.php'; ?>

<?php include './component/header.php'; ?>




<?php 
include '../db/connection.php'; 

// Add Invoice Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_invoice'])) {
    $customer_name = $_POST['customer_name'];
    $date = $_POST['date'];
    $items = $_POST['items']; // Array of items
    
    $total_amount = 0;

    // Insert into invoices table
    $stmt = $conn->prepare("INSERT INTO invoices (customer_name, date, total_amount) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $customer_name, $date, $total_amount);
    $stmt->execute();
    $invoice_id = $stmt->insert_id;
    $stmt->close();

    // Insert into invoice_items table
    foreach ($items as $item) {
        $item_name = $item['name'];
        $quantity = $item['quantity'];
        $price = $item['price'];
        $total = $quantity * $price;
        $total_amount += $total;

        $stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, item_name, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isidd", $invoice_id, $item_name, $quantity, $price, $total);
        $stmt->execute();
        $stmt->close();
    }

    // Update total amount in invoices table
    $stmt = $conn->prepare("UPDATE invoices SET total_amount = ? WHERE id = ?");
    $stmt->bind_param("di", $total_amount, $invoice_id);
    $stmt->execute();
    $stmt->close();
    
    echo "<div class='alert alert-success'>Invoice created successfully!</div>";
}
?>

<div class="container mt-5">
    <h2>Generate Invoice</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="customer_name" class="form-label">Customer Name</label>
            <input type="text" name="customer_name" id="customer_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="date" class="form-label">Date</label>
            <input type="date" name="date" id="date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="items" class="form-label">Items</label>
            <div id="items">
                <div class="row mb-2">
                    <div class="col">
                        <input type="text" name="items[0][name]" class="form-control" placeholder="Item Name" required>
                    </div>
                    <div class="col">
                        <input type="number" name="items[0][quantity]" class="form-control" placeholder="Quantity"
                            required>
                    </div>
                    <div class="col">
                        <input type="number" name="items[0][price]" class="form-control" placeholder="Price" required>
                    </div>
                </div>
            </div>
            <button type="button" id="add-item" class="btn btn-primary btn-sm">Add Item</button>
        </div>
        <button type="submit" name="add_invoice" class="btn btn-success">Generate Invoice</button>
    </form>
</div>
<!-- Table Section -->
<div class="card">
    <div class="card-header bg-primary text-white">
        <div class="d-flex justify-content-between align-items-center">
            <span>Invoice List</span>
            <form class="d-flex" method="GET" action="">
                <input class="form-control me-2" type="search" name="search" placeholder="Search by Customer Name..."
                    value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                <button class="btn btn-light" type="submit">Search</button>
            </form>
        </div>
    </div>
    ` <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Customer Name</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Include database connection
                include '../db/connection.php';

                // Search query
                $searchQuery = $_GET['search'] ?? '';
                $searchSql = $searchQuery ? "WHERE customer_name LIKE ?" : "";

                // Fetch invoices and their items
                $sql = "
                    SELECT 
                        invoices.id AS invoice_id,
                        invoices.customer_name,
                        invoices.date,
                        invoices.total_amount,
                        GROUP_CONCAT(CONCAT(invoice_items.item_name, ' (Qty: ', invoice_items.quantity, ')')) AS items
                    FROM invoices
                    LEFT JOIN invoice_items ON invoices.id = invoice_items.invoice_id
                    $searchSql
                    GROUP BY invoices.id
                ";

                $stmt = $conn->prepare($sql);
                if ($searchQuery) {
                    $searchParam = "%$searchQuery%";
                    $stmt->bind_param("s", $searchParam);
                }
                $stmt->execute();
                $result = $stmt->get_result();

                // Display results
                if ($result->num_rows > 0) {
                    $serialNumber = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $serialNumber++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['customer_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['items']) . "</td>";
                        echo "<td>" . number_format($row['total_amount'], 2) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No Invoices Found</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('add-item').addEventListener('click', function() {
    const itemsContainer = document.getElementById('items');
    const index = itemsContainer.children.length;

    const row = document.createElement('div');
    row.className = 'row mb-2';
    row.innerHTML = `
        <div class="col">
            <input type="text" name="items[${index}][name]" class="form-control" placeholder="Item Name" required>
        </div>
        <div class="col">
            <input type="number" name="items[${index}][quantity]" class="form-control" placeholder="Quantity" required>
        </div>
        <div class="col">
            <input type="number" name="items[${index}][price]" class="form-control" placeholder="Price" required>
        </div>
    `;
    itemsContainer.appendChild(row);
});
</script>
<?php include './component/footer.php'; ?>
<!-- Bootstrap and JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Sidebar Toggle
document.getElementById('menu-toggle').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('collapsed-content');
});
</script>