<?php
// Include the header and database connection
include './component/header.php';
include '../db/connection.php';

session_start();
// Start the session

// Destroy all session data
session_destroy();

// Redirect to the login page within the TTHMS directory
header( 'Location:/system/login.php
 ' );
exit();
?>