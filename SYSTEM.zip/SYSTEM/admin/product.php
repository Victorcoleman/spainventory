<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>

<body>
    <?php 
    include './component/sidebar.php'; 
    include './component/header.php'; 
    include '../db/connection.php'; 

    // Initialize variables for form
    $id = $itemName = $price = $description = "";

    // Handle form submission for Add/Update
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $itemName = $_POST['item_name'];
        $price = $_POST['price'];
        $description = $_POST['description'];

        if ($id) {
            // Update existing record
            $sql = "UPDATE products SET item_name=?, price=?, description=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sdsi", $itemName, $price, $description, $id);
        } else {
            // Add new record
            $sql = "INSERT INTO products (item_name, price, description) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sds", $itemName, $price, $description);
        }
        $stmt->execute();
        $stmt->close();
    }

    // Handle search query
    $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
    $sql = "SELECT * FROM products WHERE item_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $searchQuery . "%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <!-- Form Section -->
    <div class="container mt-5">
        <h3 class="mb-3">Manage Products</h3>
        <div class="card mb-4">
            <div class="card-header bg-success text-white">Add or Update Product</div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
                    <div class="mb-3">
                        <label for="item_name" class="form-label">Item Name</label>
                        <input type="text" class="form-control" id="item_name" name="item_name"
                            value="<?= htmlspecialchars($itemName) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01"
                            value="<?= htmlspecialchars($price) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"
                            required><?= htmlspecialchars($description) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"><?= $id ? 'Update' : 'Add' ?></button>
                </form>
            </div>
        </div>

        <!-- Table Section -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <span>Product List</span>
                    <form class="d-flex" method="GET" action="">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search..."
                            value="<?= htmlspecialchars($searchQuery) ?>">
                        <button class="btn btn-light" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item Name</th>
                            <th>Price</th>

                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $serialNumber = 1;
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $serialNumber++ . "</td>";
                                echo "<td>" . htmlspecialchars($row['item_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                             
                                echo "<td>
                                    <a href='?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete.product.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                  </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No Products Found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
    $stmt->close();
    $conn->close();
    include './component/footer.php'; 
    ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>