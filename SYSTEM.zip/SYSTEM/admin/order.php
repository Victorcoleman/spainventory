<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel='stylesheet' href='./css/admin.css'>
</head>

<body>
    <?php 
    include './component/sidebar.php'; 
    include './component/header.php'; 
    include '../db/connection.php'; 

    // Initialize variables for form
    $id = $firstName = $lastName = $email = $phoneNumber = $address = $product = $cost = "";

    // Handle form submission for Add/Update
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $firstName = $_POST['first_name'];
        $lastName = $_POST['last_name'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phone_number'];
        $address = $_POST['address'];
        $product = $_POST['product'];
        $cost = $_POST['cost'];

        if ($id) {
            // Update existing record
            $sql = "UPDATE Orders SET first_name=?, last_name=?, email=?, phone_number=?, address=?, product=?, cost=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssdi", $firstName, $lastName, $email, $phoneNumber, $address, $product, $cost, $id);
        } else {
            // Add new record
            $sql = "INSERT INTO Orders (first_name, last_name, email, phone_number, address, product, cost) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssd", $firstName, $lastName, $email, $phoneNumber, $address, $product, $cost);
        }
        $stmt->execute();
        $stmt->close();
    }

    // Handle search query
    $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
    $sql = "SELECT * FROM Orders WHERE email LIKE ? OR first_name LIKE ? OR phone_number LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $searchQuery . "%";
    $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <!-- Form Section -->
    <div class="container mt-5">
        <h3 class="mb-3">Manage Orders</h3>
        <div class="card mb-4">
            <div class="card-header bg-success text-white">Add or Update Order</div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
                    <div class="mb-3">
                        <label for="first_name" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name"
                            value="<?= htmlspecialchars($firstName) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name"
                            value="<?= htmlspecialchars($lastName) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email"
                            value="<?= htmlspecialchars($email) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone_number" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="phone_number" name="phone_number"
                            value="<?= htmlspecialchars($phoneNumber) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address"
                            value="<?= htmlspecialchars($address) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="product" class="form-label">Product</label>
                        <input type="text" class="form-control" id="product" name="product"
                            value="<?= htmlspecialchars($product) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="cost" class="form-label">Cost</label>
                        <input type="number" class="form-control" id="cost" name="cost" step="0.01"
                            value="<?= htmlspecialchars($cost) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><?= $id ? 'Update' : 'Add' ?></button>
                </form>
            </div>
        </div>

        <!-- Table Section -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <span>Order List</span>
                    <form class="d-flex" method="GET" action="">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search..."
                            value="<?= htmlspecialchars($searchQuery) ?>">
                        <button class="btn btn-light" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Product</th>
                            <th>Cost</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $serialNumber = 1;
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $serialNumber++ . "</td>";
                                echo "<td>" . htmlspecialchars($row['first_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['last_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['phone_number']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['product']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['cost']) . "</td>";
                                echo "<td>
                                    <a href='?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete.order.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                  </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='9' class='text-center'>No Orders Found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
    $stmt->close();
    $conn->close();
    include './component/footer.php'; 
    ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>