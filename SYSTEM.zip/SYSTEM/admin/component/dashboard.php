<?php
// Include database connection
include '../db/connection.php'; 

// Initialize counts to avoid undefined variable errors in case of query failure
$totalOrder = 0;
$totalAppointment = 0;
$visitorCount = 0;
$totalSubscribe = 0;

// Fetch counts with error handling
try {
    // Fetch Total Orders
    $result = $conn->query("SELECT COUNT(*) AS count FROM orders");
    if ($result && $row = $result->fetch_assoc()) {
        $totalOrder = $row['count'];
    }

    // Fetch Total Appointments
    $result = $conn->query("SELECT COUNT(*) AS count FROM appointments");
    if ($result && $row = $result->fetch_assoc()) {
        $totalAppointment = $row['count'];
    }

    // Fetch Visitor Count
    $result = $conn->query("SELECT COUNT(*) AS count FROM visitor_count");
    if ($result && $row = $result->fetch_assoc()) {
        $visitorCount = $row['count'];
    }

    // Fetch Total Subscribers
    $result = $conn->query("SELECT COUNT(*) AS count FROM subscriptions");
    if ($result && $row = $result->fetch_assoc()) {
        $totalSubscribe = $row['count'];
    }
} catch (Exception $e) {
    // Log the error (you can replace this with actual logging)
    error_log("Error fetching counts: " . $e->getMessage());
}
?>
<!-- Dashboard Cards -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card card-custom bg-blue">
            <div>Total Orders</div>
            <div><?php echo htmlspecialchars($totalOrder); ?></div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card card-custom bg-gray">
            <div>Total Appointments</div>
            <div><?php echo htmlspecialchars($totalAppointment); ?></div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card card-custom bg-red">
            <div>Visitor Count</div>
            <div><?php echo htmlspecialchars($visitorCount); ?></div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card card-custom bg-yellow">
            <div>Total Subscribers</div>
            <div><?php echo htmlspecialchars($totalSubscribe); ?></div>
        </div>
    </div>
</div>