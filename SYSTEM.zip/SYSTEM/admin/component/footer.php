<!-- Footer -->
<footer>
    <span>&copy; 2024 SMS Admin Panel</span>
</footer>