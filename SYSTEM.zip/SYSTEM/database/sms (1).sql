-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 30, 2024 at 10:22 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `appointment_type` enum('Premium','Standard','Regular') NOT NULL,
  `cost` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `address`, `appointment_type`, `cost`, `created_at`) VALUES
(5, 'Sarah', 'Jason', 'emmosei@gmail.com', '020992445', 'osu', 'Standard', 500, '2024-12-30 12:48:52'),
(4, 'kofi', 'Kevin', 'kevin3@gmail.com', '030304033', 'do', 'Premium', 1000, '2024-12-30 12:46:43'),
(6, 'Amelia', 'Nemi', 'admin1@gmail.com', '024568788', 'kok', 'Standard', 500, '2024-12-30 12:51:16'),
(7, 'Tissy', 'Pat', 'pat@gmail.com', '0233333223', 'circle22', 'Premium', 1000, '2024-12-30 14:48:45'),
(8, 'socks', 'dsm', 'dsm@gmail.com', '020200202', 'osu', 'Premium', 1000, '2024-12-30 22:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(2, 'Sam', 'meshack1@gmail.com', 'good', '2024-12-30 13:05:37');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `InventoryID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(100) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `PricePerUnit` decimal(10,2) NOT NULL,
  `Product` varchar(100) DEFAULT NULL,
  `LastRestocked` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`InventoryID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`InventoryID`, `ItemName`, `Quantity`, `PricePerUnit`, `Product`, `LastRestocked`) VALUES
(1, 'swimming costume', 20, '800.00', 'swimming costume', '2024-12-22 12:01:58'),
(2, 'swimming goggles', 50, '150.00', 'swimming goggles', '2024-12-22 12:01:58'),
(15, 'goggles kids', 77, '44.00', 'swimming costume ', '2024-12-26 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `customer_name`, `date`, `total_amount`) VALUES
(1, 'kofi', '2024-12-12', '100.00'),
(2, 'Kevin sam', '2024-12-28', '500.00'),
(3, 'Kevin sam', '2024-12-28', '500.00');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE IF NOT EXISTS `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `item_name`, `quantity`, `price`, `total`) VALUES
(1, 1, 'costume ', 1, '100.00', '100.00'),
(2, 2, 's costume  ', 2, '250.00', '500.00'),
(3, 3, 's costume  ', 2, '250.00', '500.00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `product` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `address`, `product`, `cost`, `created_at`) VALUES
(4, 'oscar', 'kojo', 'oscar@gmail.com', '02494555555', 'circle', 'swimming costume', 300, '2024-12-30 12:55:52'),
(3, 'Eric', 'mario', 'max2@gmail.com', '024999992', 'john ni', 'Swimming Costume', 800, '2024-12-30 12:52:56'),
(5, 'Betty', 'dole', 'meshack1@gmail.com', '0304030302', 'Kotobabi', 'Swimming Costume', 800, '2024-12-30 12:58:53'),
(6, 'Melvin', 'Alex', 'alex@gmail.com', '0230444424', 'dome', 'Swimming Goggles', 150, '2024-12-30 13:03:48'),
(1, 'Melvin', 'mario', 'victorco1@gmail.com', '+23393939391', 'Teshie', 'Swimming Goggles', 150, '2024-12-20 06:48:55'),
(2, 'gabby', 'Tis', 'bakacol27@gmail.com', '+23388883333', 'circle', 'Swimming Costume', 800, '2024-12-26 12:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `item_name`, `price`) VALUES
(1, 'Premium', '1000.00'),
(2, 'Standard', '500.00'),
(3, 'Regular', '350.00'),
(4, 'Swimming Costume', '800.00'),
(5, 'Swimming Goggles', '150.00');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `ServiceID` int(11) NOT NULL AUTO_INCREMENT,
  `ServiceName` varchar(100) NOT NULL,
  `Description` text,
  `Price` decimal(10,2) NOT NULL,
  `Duration` int(11) DEFAULT NULL COMMENT 'Duration in minutes',
  PRIMARY KEY (`ServiceID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `email`, `subscribed_at`) VALUES
(1, 'company@example.com', '2024-12-17 06:56:08'),
(2, 'jason1@gmail.com', '2024-12-17 07:05:41'),
(3, 'xsm@gamail.com', '2024-12-26 16:39:33'),
(4, 'kevin3@gmail.com', '2024-12-30 12:46:43'),
(5, 'emmosei@gmail.com', '2024-12-30 12:48:52'),
(6, 'pat@gmail.com', '2024-12-30 14:48:45'),
(7, 'dsm@gmail.com', '2024-12-30 22:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` char(66) NOT NULL,
  `role` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `password` (`password`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `created_at`) VALUES
(38, 'user', '6ad14ba9986e3615423dfca256d04e3f', 'user', '2024-12-30 21:51:46'),
(37, 'admin', '0192023a7bbd73250516f069df18b500', 'admin', '2024-12-30 21:45:05'),
(36, 'sam', '123', 'admin', '2024-12-30 21:39:08');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_count`
--

DROP TABLE IF EXISTS `visitor_count`;
CREATE TABLE IF NOT EXISTS `visitor_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor_count`
--

INSERT INTO `visitor_count` (`id`, `count`) VALUES
(1, 20);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
