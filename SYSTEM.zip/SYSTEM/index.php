<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oceanic Swimming</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Icons (Bootstrap Icons CDN) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel='stylesheet' href='./css/main.css'>
    <link rel='stylesheet' href='./css/vistior.css'>
    <style>

    </style>
</head>

<body>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/60c71e787f4b000ac0377adb/1f84su33i';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
    </script>
    <!--End of Tawk.to Script-->
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="text-warning">O</span>ceanic
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="Product.php">Product</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="Services.php">Our Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="About.php">About Us</a></li>
                </ul>
                <?php
// Include database connection
include './db/connection.php';

// Initialize search results
$searchResults = [];
$searchQuery = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $searchQuery = trim($_GET['search']); // Sanitize input

    // Search the database
    $sql = "SELECT item_name, price FROM products WHERE item_name LIKE ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $searchTerm = "%$searchQuery%";
        $stmt->bind_param("s", $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $searchResults[] = $row;
        }

        $stmt->close();
    } else {
        echo "<div style='color: red;'>SQL Error: " . $conn->error . "</div>";
    }

    $conn->close();
}
?>

                <!-- Search Form -->
                <form class="d-flex me-3" role="search" method="GET" action="">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search..."
                        aria-label="Search" value="<?php echo htmlspecialchars($searchQuery); ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </form>

                <!-- Search Results -->
                <div class="search-results mt-4">
                    <?php if (!empty($searchResults)): ?>
                    <h3>Search Results:</h3>
                    <ul class="list-group">
                        <?php foreach ($searchResults as $result): ?>
                        <li class="list-group-item">
                            <strong>Item:</strong> <?php echo htmlspecialchars($result['item_name']); ?> <br>
                            <strong>Price:</strong> <?php echo htmlspecialchars($result['price']); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($searchQuery)): ?>
                    <div class="alert alert-warning">No results found for
                        "<?php echo htmlspecialchars($searchQuery); ?>"</div>
                    <?php endif; ?>
                </div>

                <div class="d-flex align-items-center">
                    <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container text-center">
            <h1 class="text-warning display-4">Welcome To Oceanic Swimming</h1>
            <p class="text-white-50 fs-5">Revive your body. Connect with your soul.</p>
            <div class="mt-4">
                <a href="product.php" class="btn btn-warning btn-lg me-3">View our product</a>
                <a href="services.php" class="btn btn-outline-light btn-lg">Book a service</a>
            </div>
        </div>
    </section>

    <br>

    <!-- who we are row -->
    <div class="container">
        <div class="who-we-are row">
            <div class="col-md-5">
                <img src="./image/man.jpeg" alt="sms">
            </div>
            <div class="col-md-7 content">
                <h2>Who We Are</h2>
                <p>oceanic Swimming club has been pushed to new heights by the harmony between technology and swimming.
                    Not only has our commitment to technical advancement improved our members' swimming experiences, but
                    it has also made our company a more flexible, successful, and accessible one. .</p>
                <p>We anticipate expanding our reach in the business and swimming worlds as we continue to drive the
                    digital wave. oceanic Swimming clubwill be greatly impacted in a productive and efficient manner due
                    to the lack of a system that can help them achieve their organisational goals.To operate the system
                    to their satisfaction, patrons, end users, and consumers employ devices like computers and tablets.
                    .</p>

            </div>
        </div>
    </div>
    <?php

// Include database connection
include './db/connection.php';

// Check if the visitor is new to this session
if (!isset($_SESSION['visited'])) {
    $_SESSION['visited'] = true;

    // Increment visitor count in the database
    $sql = "UPDATE visitor_count SET count = count + 1 WHERE id = 1";
    if (!$conn->query($sql)) {
        die("Error updating visitor count: " . $conn->error);
    }
}

// Retrieve the current visitor count
$sql = "SELECT count FROM visitor_count WHERE id = 1";
$result = $conn->query($sql);
$visitorCount = $result->fetch_assoc()['count'] ?? 0;

// Close the database connection
$conn->close();
?>
    <script>
    // Hide popup after 5 seconds
    document.addEventListener("DOMContentLoaded", () => {
        setTimeout(() => {
            const popup = document.querySelector('.popup-container');
            popup.classList.add('hidden');
        }, 5000);
    });
    </script>
    </head>

    <body>
        <!-- Popup -->
        <div class="popup-container">
            <div class="popup-message">Welcome to Oceanic Swimming!</div>
        </div>

        <!-- Hidden Visitor Count -->
        <div style="display: none;">
            Visitor Count: <?php echo htmlspecialchars($visitorCount); ?>
        </div>
        <!-- Our Services -->
        <div class="container py-5">
            <h2 class="text-center mb-4">Our Services</h2>
            <div class="row text-center">
                <!-- Premium -->
                <div class="col-md-4 mb-4">
                    <div class="service-box">
                        <img src="./image/cc.jpeg" alt="Premium">
                        <div class="overlay">
                            <div class="price">GHS 1000</div>
                            <div class="service-title">Premium</div>
                            <button class="btn btn-custom mt-3" data-bs-toggle="modal"
                                data-bs-target="#appointmentModal">Book Appointment</button>
                        </div>
                    </div>
                </div>
                <!-- Body Massage -->
                <div class="col-md-4 mb-4">
                    <div class="service-box">
                        <img src="./image/good.jpeg" alt="Body Massage">
                        <div class="overlay">
                            <div class="price">GHS 500</div>
                            <div class="service-title">Standard</div>
                            <button class="btn btn-custom mt-3" data-bs-toggle="modal"
                                data-bs-target="#appointmentModal">Book Appointment</button>
                        </div>
                    </div>
                </div>
                <!-- Pedicure -->
                <div class="col-md-4 mb-4">
                    <div class="service-box">
                        <img src="./image/oc.jpeg" alt="Pedicure">
                        <div class="overlay">
                            <div class="price">GHS 350</div>
                            <div class="service-title">
                                Regular</div>
                            <button class="btn btn-custom mt-3" data-bs-toggle="modal"
                                data-bs-target="#appointmentModal">Book Appointment</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <button class="btn view-all-btn">View all our services</button>
            </div>
        </div>

        <!-- Appointment Modal -->
        <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include database connection (update path as needed)
    include './db/connection.php';

    // Sanitize and validate input
    $firstName = htmlspecialchars(trim($_POST['first_name']));
    $lastName = htmlspecialchars(trim($_POST['last_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phoneNumber = htmlspecialchars(trim($_POST['phone_number']));
    $address = htmlspecialchars(trim($_POST['address']));
    $appointmentType = htmlspecialchars(trim($_POST['appointment_type']));
    $cost = 0;

    // Determine the cost based on the appointment type
    switch ($appointmentType) {
        case 'Premium':
            $cost = 1000;
            break;
        case 'Standard':
            $cost = 500;
            break;
        case 'Regular':
            $cost = 350;
            break;
        default:
            echo "<script>alert('Invalid appointment type selected.');</script>";
            exit;
    }

    // Check if all fields are filled
    if (empty($firstName) || empty($lastName) || empty($email) || empty($phoneNumber) || empty($address) || empty($appointmentType)) {
        echo "<script>alert('All fields are required.');</script>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Please enter a valid email address.');</script>";
    } else {
        // Insert the data into the database
        $sql = "INSERT INTO appointments (first_name, last_name, email, phone_number, address, appointment_type, cost) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssssssi", $firstName, $lastName, $email, $phoneNumber, $address, $appointmentType, $cost);

            if ($stmt->execute()) {
                echo "<script>alert('Appointment booked successfully!');</script>";
            } else {
                echo "<script>alert('Error: " . $stmt->error . "');</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('SQL Error: " . $conn->error . "');</script>";
        }

        $conn->close();
    }
}
?>

        <!-- Appointment Modal -->
        <div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="appointmentModalLabel">Book Appointment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="firstName" class="form-label">First Name</label>
                                <input type="text" name="first_name" class="form-control" id="firstName" required>
                            </div>
                            <div class="mb-3">
                                <label for="lastName" class="form-label">Last Name</label>
                                <input type="text" name="last_name" class="form-control" id="lastName" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="phoneNumber" class="form-label">Phone Number</label>
                                <input type="tel" name="phone_number" class="form-control" id="phoneNumber" required>
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" id="address" required>
                            </div>
                            <div class="mb-3">
                                <label for="appointmentType" class="form-label">Appointment Type</label>
                                <select name="appointment_type" class="form-select" id="appointmentType" required>
                                    <option value="Premium">Premium - 1000</option>
                                    <option value="Standard">Standard - 500</option>
                                    <option value="Regular">Regular - 350</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-custom">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- subscribe -->
        <?php
include './db/connection.php'; // Ensure connection.php initializes $conn properly

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']); // Sanitize input
    // Validate email format
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Prepare the SQL statement
        $sql = "INSERT INTO subscriptions (email) VALUES (?)";
        $stmt = $conn->prepare($sql);

        // Check if the statement was prepared successfully
        if ($stmt) {
            $stmt->bind_param("s", $email);

            // Execute and check for success
            if ($stmt->execute()) {
                // Use inline JavaScript to show a success alert
                echo "<script>alert('You have successfully subscribed!');</script>";
            } else {
                echo "<div style='color: red;'>Error: " . $stmt->error . "</div>";
            }

            $stmt->close();
        } else {
            // Output error if statement preparation failed
            echo "<div style='color: red;'>SQL Error: " . $conn->error . "</div>";
        }
    } else {
        echo "<div style='color: red;'>Invalid email address!</div>";
    }

    $conn->close(); // Close connection
}
?>

        <div class="subscription-section">
            <h2>Let's Stay Connected!</h2>
            <p>Receive our news and special offers</p>
            <div class="subscription-form">
                <form method="POST" action="">
                    <input type="email" name="email" placeholder="Email" required>
                    <button type="submit">Subscribe</button>
                </form>
            </div>
        </div>

        <!-- subscribe -->

        <!-- footer -->

        <footer>
            <div class="container">
                <div class="row">
                    <!-- About Section -->
                    <div class="col-md-4 footer-section">
                        <div class="footer-logo">oceanic</div>
                        <p class="footer-description">
                            oceanic Swimming club has been pushed to new heights by the harmony between technology and
                            swimming. Not only has our commitment to technical advancement improved our members'
                            swimming
                            experiences, but it has also made our company a more flexible, successful, and accessible
                            one.
                        </p>
                    </div>

                    <!-- Services Section -->
                    <div class="col-md-2 footer-section">
                        <h5>Services</h5>
                        <ul>
                            <li><a href="#">Premium</a></li>
                            <li><a href="#">Standard</a></li>
                            <li><a href="#">Regular</a></li>
                            <li><a href="#">All</a></li>

                        </ul>
                    </div>

                    <!-- Contact Section -->
                    <div class="col-md-3 footer-section">
                        <h5>Contact</h5>
                        <ul>
                            <li><i class="bi bi-telephone"></i> +232556773</li>
                            <li><i class="bi bi-whatsapp"></i> 0202334914</li>
                            <li><i class="bi bi-envelope"></i> oceanic@gmail.com</li>
                            <li><i class="bi bi-geo-alt"></i> Kotobabi, Accra-Ghana</li>
                        </ul>
                    </div>

                    <!-- Quick Links Section -->
                    <div class="col-md-3 footer-section">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="Contact.php">Contact</a></li>
                            <li><a href="Services.php">Services</a></li>
                            <li><a href="About.php">About</a></li>
                        </ul>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col text-center social-icons">
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-youtube"></i></a>
                        <a href="#"><i class="bi bi-pinterest"></i></a>
                    </div>
                </div>

                <div class="footer-bottom">
                    <p>© Copyright 2024 oceanic. All rights reserved | Developed by Coleman</p>
                </div>
            </div>
        </footer>



        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    </body>

</html>