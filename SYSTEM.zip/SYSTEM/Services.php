<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oceanic Swimming</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Icons (Bootstrap Icons CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel='stylesheet' href='./css/main.css'>

    <style>

    </style>
</head>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <span class="text-warning">O</span>ceanic
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="Product.php">Product</a></li>
                <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
                <li class="nav-item"><a class="nav-link" href="Services.php">Our Services</a></li>
                <li class="nav-item"><a class="nav-link" href="About.php">About Us</a></li>
            </ul>
            <form class="d-flex me-3" role="search">
                <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search">
            </form>
            <div class="d-flex align-items-center">
                <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
            </div>
        </div>
    </div>
</nav>



<!-- Our Services -->
<div class="container py-5">
    <h2 class="text-center mb-4">Our Services</h2>
    <div class="row text-center">
        <!-- Premium -->
        <div class="col-md-4 mb-4">
            <div class="service-box">
                <img src="./image/cc.jpeg" alt="Premium">
                <div class="overlay">
                    <div class="price">GHS 1000</div>
                    <div class="service-title">Premium</div>
                    <button class="btn btn-custom mt-3" data-bs-toggle="modal" data-bs-target="#appointmentModal">Book
                        Appointment</button>
                </div>
            </div>
        </div>
        <!-- Body Massage -->
        <div class="col-md-4 mb-4">
            <div class="service-box">
                <img src="./image/good.jpeg" alt="Body Massage">
                <div class="overlay">
                    <div class="price">GHS 500</div>
                    <div class="service-title">Standard</div>
                    <button class="btn btn-custom mt-3" data-bs-toggle="modal" data-bs-target="#appointmentModal">Book
                        Appointment</button>
                </div>
            </div>
        </div>
        <!-- Pedicure -->
        <div class="col-md-4 mb-4">
            <div class="service-box">
                <img src="./image/oc.jpeg" alt="Pedicure">
                <div class="overlay">
                    <div class="price">GHS 350</div>
                    <div class="service-title">
                        Regular</div>
                    <button class="btn btn-custom mt-3" data-bs-toggle="modal" data-bs-target="#appointmentModal">Book
                        Appointment</button>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center">
        <button class="btn view-all-btn">View all our services</button>
    </div>
</div>

<!-- Appointment Modal -->
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include database connection (update path as needed)
    include './db/connection.php';

    // Sanitize and validate input
    $firstName = htmlspecialchars(trim($_POST['first_name']));
    $lastName = htmlspecialchars(trim($_POST['last_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phoneNumber = htmlspecialchars(trim($_POST['phone_number']));
    $address = htmlspecialchars(trim($_POST['address']));
    $appointmentType = htmlspecialchars(trim($_POST['appointment_type']));
    $cost = 0;

    // Determine the cost based on the appointment type
    switch ($appointmentType) {
        case 'Premium':
            $cost = 1000;
            break;
        case 'Standard':
            $cost = 500;
            break;
        case 'Regular':
            $cost = 350;
            break;
        default:
            echo "<script>alert('Invalid appointment type selected.');</script>";
            exit;
    }

    // Check if all fields are filled
    if (empty($firstName) || empty($lastName) || empty($email) || empty($phoneNumber) || empty($address) || empty($appointmentType)) {
        echo "<script>alert('All fields are required.');</script>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Please enter a valid email address.');</script>";
    } else {
        // Insert the data into the database
        $sql = "INSERT INTO appointments (first_name, last_name, email, phone_number, address, appointment_type, cost) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssssssi", $firstName, $lastName, $email, $phoneNumber, $address, $appointmentType, $cost);

            if ($stmt->execute()) {
                echo "<script>alert('Appointment booked successfully!');</script>";
            } else {
                echo "<script>alert('Error: " . $stmt->error . "');</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('SQL Error: " . $conn->error . "');</script>";
        }

        $conn->close();
    }
}
?>

<!-- Appointment Modal -->
<div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="appointmentModalLabel">Book Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name</label>
                        <input type="text" name="first_name" class="form-control" id="firstName" required>
                    </div>
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name</label>
                        <input type="text" name="last_name" class="form-control" id="lastName" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber" class="form-label">Phone Number</label>
                        <input type="tel" name="phone_number" class="form-control" id="phoneNumber" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" name="address" class="form-control" id="address" required>
                    </div>
                    <div class="mb-3">
                        <label for="appointmentType" class="form-label">Appointment Type</label>
                        <select name="appointment_type" class="form-select" id="appointmentType" required>
                            <option value="Premium">Premium - 1000</option>
                            <option value="Standard">Standard - 500</option>
                            <option value="Regular">Regular - 350</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-custom">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- footer -->

<footer>
    <div class="container">
        <div class="row">
            <!-- About Section -->
            <div class="col-md-4 footer-section">
                <div class="footer-logo">oceanic</div>
                <p class="footer-description">
                    oceanic Swimming club has been pushed to new heights by the harmony between technology and
                    swimming. Not only has our commitment to technical advancement improved our members' swimming
                    experiences, but it has also made our company a more flexible, successful, and accessible one.
                </p>
            </div>

            <!-- Services Section -->
            <div class="col-md-2 footer-section">
                <h5>Services</h5>
                <ul>
                    <li><a href="#">Premium</a></li>
                    <li><a href="#">Standard</a></li>
                    <li><a href="#">Regular</a></li>
                    <li><a href="#">All</a></li>

                </ul>
            </div>

            <!-- Contact Section -->
            <div class="col-md-3 footer-section">
                <h5>Contact</h5>
                <ul>
                    <li><i class="bi bi-telephone"></i> +232556773</li>
                    <li><i class="bi bi-whatsapp"></i> 0202334914</li>
                    <li><i class="bi bi-envelope"></i> oceanic@gmail.com</li>
                    <li><i class="bi bi-geo-alt"></i> Kotobabi, Accra-Ghana</li>
                </ul>
            </div>

            <!-- Quick Links Section -->
            <div class="col-md-3 footer-section">
                <h5>Quick Links</h5>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">About</a></li>
                </ul>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col text-center social-icons">
                <a href="#"><i class="bi bi-twitter"></i></a>
                <a href="#"><i class="bi bi-facebook"></i></a>
                <a href="#"><i class="bi bi-youtube"></i></a>
                <a href="#"><i class="bi bi-pinterest"></i></a>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© Copyright 2024 oceanic. All rights reserved | Developed by Coleman</p>
        </div>
    </div>
</footer>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>