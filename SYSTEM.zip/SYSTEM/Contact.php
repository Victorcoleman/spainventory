<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oceanic Swimming</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Icons (Bootstrap Icons CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel='stylesheet' href='./css/main.css'>

    <style>

    </style>
</head>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <span class="text-warning">O</span>ceanic
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="Product.php">Product</a></li>
                <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
                <li class="nav-item"><a class="nav-link" href="Services.php">Our Services</a></li>
                <li class="nav-item"><a class="nav-link" href="About.php">About Us</a></li>
            </ul>
            <form class="d-flex me-3" role="search">
                <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search">
            </form>
            <div class="d-flex align-items-center">
                <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
            </div>
        </div>
    </div>
</nav>


<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include database connection (update path to your connection file)
    include './db/connection.php';

    // Sanitize and validate input
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Initialize an empty error message
    $errorMessage = '';

    // Validate form inputs
    if (empty($name) || empty($email) || empty($message)) {
        $errorMessage = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Please enter a valid email address.";
    }

    if (empty($errorMessage)) {
        // Prepare SQL statement
        $sql = "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("sss", $name, $email, $message);

            if ($stmt->execute()) {
                echo "<script>alert('Message sent successfully!');</script>";
            } else {
                echo "<script>alert('Error: " . $stmt->error . "');</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('SQL Error: " . $conn->error . "');</script>";
        }
        $conn->close();
    } else {
        echo "<script>alert('$errorMessage');</script>";
    }
}
?>

<!-- Contact Header -->
<div class="contact-header">
    <h1>Contact Us</h1>
</div>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <div class="row">
            <!-- Contact Form -->
            <div class="col-md-6">
                <h2 class="text-center mb-4">Send Us a Message</h2>
                <form class="contact-form" method="POST" action="">
                    <div class="form-group">
                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" class="form-control" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <textarea name="message" class="form-control" placeholder="Message" rows="5"
                            required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Send</button>
                </form>
            </div>

            <!-- Contact Info -->
            <div class="col-md-6">
                <h2 class="text-center mb-4">Contact Information</h2>
                <ul class="contact-info list-unstyled">
                    <li><i class="bi bi-telephone"></i> +237778666</li>
                    <li><i class="bi bi-whatsapp"></i> 023588885</li>
                    <li><i class="bi bi-envelope"></i> oceanic@gmail.com</li>
                    <li><i class="bi bi-geo-alt"></i> Kotobabi, Accra-Ghana</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- footer -->

<footer>
    <div class="container">
        <div class="row">
            <!-- About Section -->
            <div class="col-md-4 footer-section">
                <div class="footer-logo">oceanic</div>
                <p class="footer-description">
                    oceanic Swimming club has been pushed to new heights by the harmony between technology and
                    swimming. Not only has our commitment to technical advancement improved our members' swimming
                    experiences, but it has also made our company a more flexible, successful, and accessible one.
                </p>
            </div>

            <!-- Services Section -->
            <div class="col-md-2 footer-section">
                <h5>Services</h5>
                <ul>
                    <li><a href="#">Premium</a></li>
                    <li><a href="#">Standard</a></li>
                    <li><a href="#">Regular</a></li>
                    <li><a href="#">All</a></li>

                </ul>
            </div>

            <!-- Contact Section -->
            <div class="col-md-3 footer-section">
                <h5>Contact</h5>
                <ul>
                    <li><i class="bi bi-telephone"></i> +232556773</li>
                    <li><i class="bi bi-whatsapp"></i> 0202334914</li>
                    <li><i class="bi bi-envelope"></i> oceanic@gmail.com</li>
                    <li><i class="bi bi-geo-alt"></i> Kotobabi, Accra-Ghana</li>
                </ul>
            </div>

            <!-- Quick Links Section -->
            <div class="col-md-3 footer-section">
                <h5>Quick Links</h5>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">About</a></li>
                </ul>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col text-center social-icons">
                <a href="#"><i class="bi bi-twitter"></i></a>
                <a href="#"><i class="bi bi-facebook"></i></a>
                <a href="#"><i class="bi bi-youtube"></i></a>
                <a href="#"><i class="bi bi-pinterest"></i></a>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© Copyright 2024 oceanic. All rights reserved | Developed by Coleman</p>
        </div>
    </div>
</footer>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>