<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar">
            <div class="text-center mb-4">
                <a href="index.php">
                    <img src="../image/logo.png" alt="Logo" class="img-fluid rounded-circle" style="max-width: 100px;">
                </a>
            </div>
            <h5 class="text-center mb-3">Oceanic Admin Panel</h5>
            <div class="list-group list-group-flush">
                <a href="index.php" class="list-group-item list-group-item-action"><i class="bi bi-house-door"></i>
                    Dashboard</a>
                <a href="product.php" class="list-group-item list-group-item-action"><i class="bi bi-box"></i>
                    Product</a>
                <a href="order.php" class="list-group-item list-group-item-action"><i class="bi bi-person"></i>
                    order</a>
                <a href="Appointments.php" class="list-group-item list-group-item-action"><i class="bi bi-calendar"></i>
                    Appointments</a>

           
                <a href="invoices.php" class="list-group-item list-group-item-action"><i
                        class="bi bi-file-earmark-spreadsheet"></i> Invoices</a>
                <a href="inventory.php" class="list-group-item list-group-item-action"><i class="bi bi-boxes"></i>
                    Inventory</a>
                <a href="Subscribe.php" class="list-group-item list-group-item-action"><i class="bi bi-bell"></i>
                    Subscribe</a>
                <a href="receipt.php" class="list-group-item list-group-item-action"><i
                        class="bi bi-file-earmark-text"></i> Receipt</a>
                <a href="visitor.php" class="list-group-item list-group-item-action"><i class="bi bi-envelope"></i>
                    NV</a>
            </div>
        </nav>