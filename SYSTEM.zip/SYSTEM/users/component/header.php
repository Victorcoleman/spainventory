<!-- Main Content -->
<main id="main-content" class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg border-bottom mb-4">
        <button class="btn btn-primary me-2" id="menu-toggle" aria-label="Toggle Sidebar">
            <i class="bi bi-list"></i>
        </button>
        <div class="dropdown ms-auto">
            <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <span class="me-2">A</span> ADMIN
            </button>
            <ul class="dropdown-menu">

                <li><a class="dropdown-item" href="Logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>